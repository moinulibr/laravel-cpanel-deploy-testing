<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

    
<!-- Mirrored from chimpgroup.com/themeforest/edu2/blue/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 30 Jun 2023 10:04:54 GMT -->
<head>
        <meta charset="utf-8">
        <meta name="description" content="&amp;lt;blockquote&amp;gt;Need Online Support or have any presale – Question ?&amp;lt;/blockquote&amp;gt;
&amp;lt;...">
        <meta http-equiv="X-UA-Compatible" content="chrome=1">
        <meta name="robots" content="noindex, nofollow" />
        <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1" />
        <meta name="turbo-visit-control" content="reload">
        <title>College02</title>
        <!-- Stylesheet -->
        <link href="https://chimpgroup.com/themeforest/edu2/blue/css/style.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="https://chimpgroup.com/themeforest/edu2/blue/css/ddsmoothmenu.css" />
        <link rel="stylesheet" type="text/css" href="https://chimpgroup.com/themeforest/edu2/blue/css/responsive.css" />
        <link rel="stylesheet" type="text/css" href="https://chimpgroup.com/themeforest/edu2/blue/css/jquery.fancybox-1.3.4.css" media="screen" />
        <!-- Javascript -->
        <script src="https://chimpgroup.com/themeforest/edu2/blue/js/jquery.min.js" type="text/javascript"></script>
        <script src="https://chimpgroup.com/themeforest/edu2/blue/js/ddsmoothmenu.js" type="text/javascript"></script>
        <script src="https://chimpgroup.com/themeforest/edu2/blue/js/contentslider.js" type="text/javascript"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/jcarousellite_1.0.1.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/jquery.easing.1.1.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/cufon-yui.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/DIN_500.font.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/menu.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/tabs.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/jquery.mousewheel-3.0.4.pack.js"></script>
        <script type="text/javascript" src="https://chimpgroup.com/themeforest/edu2/blue/js/jquery.fancybox-1.3.4.pack.js"></script>
    </head>
    <body>
        <div id="bg">
            <!-- Wapper Sec -->
            <div id="wrapper_sec">
                <!-- masterhead -->
                <div id="masterhead">
                    <!-- Logo -->
                    <div class="logo"><a href="https://chimpgroup.com/themeforest/edu2/blue/index.html"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/logo.png" alt="" /></a></div>
                    <!-- masterhead Right Section -->
                    <div class="topright_sec">
                        <!-- top navigation -->
                        <div class="topnavigation">
                            <ul>
                                <li class="first">&nbsp;</li>
                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/news.html">News</a></li>
                                <li><a href="#">Events</a></li>
                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/blog.html">Blog</a></li>
                                <li><a href="#">Jobs</a></li>
                                <li><a href="#">Student Profile </a></li>
                                <li><a href="#">Our Campuses</a></li>
                                <li><a class="nobg" href="#"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/rss.gif" alt="" /></a></li>
                                <li class="last">&nbsp;</li>
                            </ul>
                        </div>
                        <div class="clear"></div>
                        <!-- top search -->
                        <div class="top_search">
                            <div class="advance_search"><a href="#">Advance Option</a></div>
                            <ul>
                                <li><input name="txt" value="Search you any keyword" onfocus="if(this.value=='Search you any keyword') {this.value='';}" onblur="if(this.value=='') {this.value='Search you any keyword';}" type="text" /></li>
                                <li><a class="search" href="#">Search</a></li>
                            </ul>
                        </div>
                        <div class="clear"> </div>
                    </div>
                    <div class="clear"></div>
                    <!-- Navigation -->
                    <div class="navigation">
                        <div id="smoothmenu1" class="ddsmoothmenu">
                            <ul id="menus">
                                <li class="first"><a class="selected" href="https://chimpgroup.com/themeforest/edu2/blue/index.html">Home</a></li>
                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/static.html">About Us</a></li>
                                <li><a href="#">Admissions</a></li>
                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Academics</a>
                                    <!-- Sub Menu level 1 -->
                                    <ul>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Integer eu mi lorem, sit amet</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html" class="dropdown">Accumsan neque</a>
                                            <!-- Sub Menu Level 2 -->
                                            <ul>
                                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">nteger eu mi lorem, sit amet</a></li>
                                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Accumsan neque</a></li>
                                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Donec varius arcu eu quam</a></li>
                                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Rutrum rhoncus.</a></li>
                                                <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Donec suscipit enim et</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Donec varius arcu eu quam</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Rutrum rhoncus.</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Donec suscipit enim et </a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Ipsum eleifend quis luctus</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Arcu scelerisque.</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Duis a tortor tellusvel egestas</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Research</a> </li>
                                <li><a href="#">Campus &amp; Community</a></li>
                                <li><a href="#">Support Us</a> </li>
                                <li><a href="#">Pages</a>
                                    <ul>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/index.html">Home</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/course.html">Courses</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/blog.html">Blog</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/blogdetail.html">Blog Detail</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/news.html">News</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/gallery.html">Gallery</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/contact.html">Contact</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/static.html">Static</a></li>
                                    </ul>
                                </li>
                                <li><a href="#" class="last">Themes</a>
                                    <ul>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/blue/index.html">Blue</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/green/index.html">Green</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/gray/index.html">Gray</a></li>
                                        <li><a href="https://chimpgroup.com/themeforest/edu2/teal/index.html">Teal</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!-- navigation ends -->
                        <div class="clear"></div>
                    </div>
                </div>
                <!-- Content Seciton -->
               <?php echo $__env->yieldContent('content'); ?>
                <div class="clear"></div>
            </div>
        </div>
        <!-- Footer Section -->
        <div id="bottom_seciton">
            <div id="footer">
                <!--Find your way -->
                <div class="find_your_way">
                    <h5>Find your Way</h5>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Site map</a></li>
                        <li><a href="#">International students</a></li>
                        <li><a href="#">About Collegeme</a></li>
                        <li><a href="#">Current Students</a></li>
                        <li><a href="#">Staff</a></li>
                    </ul>
                </div>
                <!-- Help and Support -->
                <div class="help_support">
                    <h5>Help &amp;Support</h5>
                    <ul>
                        <li><a href="#">Academic Calendar</a></li>
                        <li><a href="#">Bookstore</a></li>
                        <li><a href="#">Colleges &amp; Schools</a></li>
                        <li><a href="#">Courses</a></li>
                        <li><a href="#">Professional Programs</a></li>
                        <li><a href="#">Our Help Desk</a></li>
                    </ul>
                </div>
                <!-- Quick Links -->
                <div class="quick_links">
                    <h5>Quick Links</h5>
                    <ul>
                        <li><a href="#">Directories</a></li>
                        <li><a href="#">Site map</a></li>
                        <li><a href="#">cMail | xMail</a></li>
                        <li><a href="#">Campus Notices</a></li>
                        <li><a href="#">Emergency Information</a></li>
                        <li><a href="#">Staff</a></li>
                    </ul>
                </div>
                <!-- Addmission -->
                <div class="Addmissoin">
                    <h5>Addmission</h5>
                    <ul>
                        <li><a href="#">Business</a></li>
                        <li><a href="#">Financial Aid</a></li>
                        <li><a href="#">Graduate</a></li>
                        <li><a href="#">Law</a></li>
                        <li><a href="#">Undergraduate</a></li>
                        <li><a href="#">School</a></li>
                    </ul>
                </div>
                <!-- Contact Us -->
                <div class="contact_us">
                    <h5>Contact Us</h5>
                    <ul>
                        <li class="telephone_no">+44 (12) 123 4567 891</li>
                        <li class="mailing_address">
                            Lorem ipsum dolor sit amet
                            consectetur adipis.
                        </li>
                        <li class="email_address"><a href="#">info@college.com</a></li>
                        <li class="googlemaps"><a href="#">Google Maps</a></li>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <!-- Bototm seciton -->
        <div id="bottom_Section">
            <!-- page bottm -->
            <div id="pagebottom">
                <!-- copyright -->
                <div class="copyright">&copy; 2011 <a href="#">College Site</a> All Rights Reserved</div>
                <a href="#" class="top">Top</a>
                <!-- Social Networks -->
                <div class="socail_networks">
                    <ul>
                        <li class="servcies">Follows us our servcies</li>
                        <li><a href="#"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/facebook_icon.gif" alt="" /> </a></li>
                        <li><a href="#"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/linkedin_icon.gif" alt="" /> </a></li>
                        <li><a href="#"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/twitter_icon.gif" alt="" /> </a></li>
                        <li><a href="#"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/rssfeed_icon.gif" alt="" /> </a></li>
                        <li><a href="#"><img src="https://chimpgroup.com/themeforest/edu2/blue/images/social_icon.gif" alt="" /> </a></li>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </body>

<!-- Mirrored from chimpgroup.com/themeforest/edu2/blue/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 30 Jun 2023 10:04:54 GMT -->
</html>
<?php /**PATH E:\xampp\htdocs\madrasa\resources\views/frontend/app.blade.php ENDPATH**/ ?>