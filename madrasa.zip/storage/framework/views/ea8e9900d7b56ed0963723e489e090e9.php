<ul class="nav">
    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->segment(2)=='academic-setup'?'active':''); ?> btn btn-sm" aria-current="page" href="<?php echo e(route('admin.academicSetup')); ?>">Active</a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->segment(2)=='sections'?'active':''); ?> btn btn-sm" href="<?php echo e(route('admin.sections.index')); ?>"> Section</a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->segment(2)=='classes'?'active':''); ?> btn btn-sm" href="#">Class</a>
    </li>

  </ul><?php /**PATH E:\xampp\htdocs\madrasa\resources\views/backend/academic/nav.blade.php ENDPATH**/ ?>