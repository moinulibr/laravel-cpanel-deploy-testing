
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Section </h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Section List </li>
        </ol>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Manage Section
                <?php echo $__env->make('backend.academic.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                        <form action="<?php echo e(route('admin.sections.store')); ?>" method="POST" id="ajax_form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <div class="form-group">
                                        <strong for="section">Section Name</strong>
                                        <input type="text" id="section" class="form-control" name="name" placeholder="Enter Section name...">
                                    </div>
                                </div>
                            </div>
                            <input type="submit" value="Save" class="btn btn-success">
                            <hr>
                        </form>
                    </div>
                    <div class="col-sm-6">
                        
                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Sl</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th style="width: 125px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($key+1); ?></td>
                                        <td> <?php echo e($item->name); ?></td>
                                        <td> <?php echo e($item->status=='1'?'active':'de-active'); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.edit')): ?>
                                            <a href="<?php echo e(route('admin.sections.edit',[$item->id])); ?>" class="action-icon btn_modal"> 
                                                <i class="fa fa-edit"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.delete')): ?>
                                                <a href="<?php echo e(route('admin.sections.destroy',[$item->id])); ?>" class="delete action-icon"> 
                                                    <i class="fa fa-trash"></i></a>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>

                    </div>
                </div>
                
            </div>
        </div>
    </div>
</main>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\madrasa\resources\views/backend/academic/sections/index.blade.php ENDPATH**/ ?>