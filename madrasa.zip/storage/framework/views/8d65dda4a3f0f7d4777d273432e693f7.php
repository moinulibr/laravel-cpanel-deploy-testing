
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Roles</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Roles List</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Manage Roles
            </div>
            <div class="card-body">

                <div class="row mb-2">
                    <div class="col-xl-4">
                        <div class="">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create')): ?>
                                <a type="button" href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-danger mb-2 me-2">
                                    <i class="fas fa-plus"></i> Add New Role</a>
                                <?php endif; ?>
                           
                        
                        </div>
                    </div><!-- end col-->
                </div>

                <div class="table-responsive">
                    <table class="table table-centered table-nowrap mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Role</th>
                                <th style="width: 125px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($role->name); ?></td>
                                <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.delete')): ?>
                                <a href="<?php echo e(route('admin.roles.edit',[$role->id])); ?>" class="action-icon"> <i class="fas fa-edit"></i></a>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.delete')): ?>
                                    <a href="<?php echo e(route('admin.roles.destroy',[$role->id])); ?>" class="delete action-icon"> <i class="fas fa-trash"></i></a>
                                <?php endif; ?>
                             
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($roles->links()); ?>


                </div>
            </div>
        </div>
    </div>
</main>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\madrasa\resources\views/backend/roles/index.blade.php ENDPATH**/ ?>