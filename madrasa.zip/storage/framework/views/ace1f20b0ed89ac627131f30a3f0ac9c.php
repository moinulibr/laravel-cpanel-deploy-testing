
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Permission </h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Permission  List</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Manage Permission 
            </div>
            <div class="card-body">

                <div class="row mb-2">
                    <div class="col-xl-4">
                        <div class="">
                            
                                <a type="button" href="<?php echo e(route('admin.permissions.create')); ?>" class="btn btn-danger mb-2 me-2">
                                    <i class="fas fa-plus"></i> Add New Permission</a>
                           
                        
                        </div>
                    </div><!-- end col-->
                </div>

                <div class="table-responsive">
                    <table class="table table-centered table-nowrap mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Permission</th>
                                <th style="width: 125px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($permission->name); ?></td>
                                <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.edit')): ?>
                                <a href="<?php echo e(route('admin.permissions.edit',[$permission->id])); ?>" class="action-icon"> <i class="fa fa-edit"></i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.delete')): ?>
                                    <a href="<?php echo e(route('admin.permissions.destroy',[$permission->id])); ?>" class="delete action-icon"> <i class="fa fa-trash"></i></a>
                                <?php endif; ?>
                               
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($permissions->links()); ?>

                </div>
            </div>
        </div>
    </div>
</main>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\madrasa\resources\views/backend/permissions/index.blade.php ENDPATH**/ ?>