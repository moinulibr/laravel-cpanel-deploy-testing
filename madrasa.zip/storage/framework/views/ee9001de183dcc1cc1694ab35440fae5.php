
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Users</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Users Add</li>
        </ol>


        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Users Add
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" id="ajax_form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                
                        <div class="col-md-6">
                            <div class="form-group">
                                <strong for="last_name">Full Name</strong>
                                <input type="text" id="last_name" class="form-control" name="name" placeholder="Full name..." value="<?php echo e(old('name')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <strong for="email">Email</strong>
                                <input type="email" id="email" class="form-control" name="email" placeholder="Email..." value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>
                 
                        <div class="col-md-6">
                            <div class="form-group">
                                <strong for="password">Password</strong>
                                <input type="password" id="password" class="form-control" name="password" placeholder="Password..." value="<?php echo e(old('password')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <strong for="confirm_password">Confirm Password</strong>
                                <input type="password" id="confirm_password" class="form-control" name="confirm_password" placeholder="Re-type Password..." value="<?php echo e(old('confirm_password')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <strong for="role">Role</strong>
                                 <select name="role" id="role" class="form-control">
                                    <option value="" disabled selected>Choose a Role</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>  
                            </div>
                        </div>
                    </div>
                    <br>
                    <input type="submit" value="Save" class="btn btn-success">
                    <hr>
                </form>

            </div>
        </div>
    </div>
</main>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\madrasa\resources\views/backend/users/create.blade.php ENDPATH**/ ?>